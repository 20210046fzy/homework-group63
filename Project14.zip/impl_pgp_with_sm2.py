import base64
import binascii
import json
from gmssl import sm2, func, sm4
#16进制的公钥和私钥
private_key = '00B9AB0B828FF68872F21A837FC303668428DEA11DCD1B24429D0C99E24EED83D5'
public_key = 'B9C9A6E04E9C91F7BA880429273747D7EF5DDEB0BB2FF6317EB00BEF331A83081A6994B8993F3F5D6EADDDB81872266C87C018FB4162F5AF347B483E24620207'
#自定义的key
SM_key=b'IMPLYPHPWITHSM2'

def  encode_sm4(value,SM_KEY):
    #sm4加密
    value=bytes(json.dumps(value),'utf-8')
    crypt_sm4=CryptSM4()
    crypt_sm4.set_key(SM_KEY,SM4_ENCRYPT)

    encrypt_value=crypt_sm4.crypt_ecb(value)
    return encrypt_value

def decode_sm4(value,SM_KEY):
    #sm4解密
    crypt_sm4=CryptSM4()
    crypt_sm4.set_key(SM_KEY,SM4_DECRYPT)

    decrypt_value=crypt_sm4.crypt_ecb(value)
    value=json.loads(str(decrypt_value,'utf-8'))
    return value

#消息内容
data=b'hello world'
#创建SM2对象
sm2_crypt = sm2.CryptSM2(
    public_key=public_key, private_key=private_key)

#公钥加密
enc_data = sm2_crypt.encrypt(SM_key)
#print("公钥加密后:",pub_key)
message=encode_sm4(data,SM_key)

#公钥解密
dec_data =sm2_crypt.decrypt(pub_key)
#print("解密后的明文为:",pub_key)
